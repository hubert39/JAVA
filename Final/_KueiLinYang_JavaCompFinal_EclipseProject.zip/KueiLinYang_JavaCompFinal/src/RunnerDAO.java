/**
 * An interface RunnerDAO extends from RunnerReader interface
 * 
 * @author Kuei-Lin Yang
 * Mar 23, 2018
 */
public interface RunnerDAO extends RunnerReader{

}
